# randSTRING
A method package that allows user to generate random package with predefined criteria
